import {
  Component, OnInit, OnDestroy, AfterViewInit,
  ElementRef, ViewChild, NgZone,
  ChangeDetectionStrategy, ChangeDetectorRef,
  signal, computed,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { Subscription } from 'rxjs';

import {
  IonHeader, IonToolbar, IonTitle, IonContent,
  IonCard, IonCardHeader, IonCardTitle, IonCardSubtitle,
  IonCardContent, IonButton, IonIcon,
  IonSpinner, IonChip, IonLabel,
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import {
  videocam, videocamOff, colorWand, lockClosedOutline,
  speedometerOutline, eyeOutline, informationCircleOutline,
  alertCircleOutline, refreshOutline,
} from 'ionicons/icons';

import { OpenCvService } from '../opencv.service';

type AppState = 'idle' | 'requesting' | 'active' | 'error';
const SHARPNESS_EVERY  = 5;
const FPS_ALPHA        = 0.85;

@Component({
  selector:        'app-home',
  standalone:      true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    IonHeader, IonToolbar, IonTitle, IonContent,
    IonCard, IonCardHeader, IonCardTitle, IonCardSubtitle,
    IonCardContent, IonButton, IonIcon,
    IonSpinner, IonChip, IonLabel,
  ],
  templateUrl: './home.page.html',
  styleUrls:   ['./home.page.scss'],
})
export class HomePage implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('videoEl')   videoRef!:  ElementRef<HTMLVideoElement>;
  @ViewChild('canvasLive') canvasRef!: ElementRef<HTMLCanvasElement>;

  readonly Math = Math;

  appState    = signal<AppState>('idle');
  fps         = signal(0);
  sharpness   = signal(0);
  opencvReady = signal(false);
  errorMsg    = signal('');
  frameCount  = signal(0);

  isActive    = computed(() => this.appState() === 'active');
  isRequesting= computed(() => this.appState() === 'requesting');
  isError     = computed(() => this.appState() === 'error');

  sharpnessLabel = computed(() => {
    const s = this.sharpness();
    if (s === 0)   return '—';
    if (s < 50)    return 'Borrosa';
    if (s < 150)   return 'Aceptable';
    if (s < 300)   return 'Nítida';
    return 'Muy nítida';
  });

  sharpnessColor = computed(() => {
    const s = this.sharpness();
    if (s < 50)  return 'danger';
    if (s < 150) return 'warning';
    return 'success';
  });

  fpsColor = computed(() => {
    const f = this.fps();
    if (f < 15) return 'danger';
    if (f < 25) return 'warning';
    return 'success';
  });

  private stream:       MediaStream | null = null;
  private rafId:        number | null      = null;
  private lastTime      = 0;
  private fpsSmoothed   = 0;
  private frameCounter  = 0;
  private viewReady     = false;
  private cvSub!:       Subscription;

  constructor(
    private opencv: OpenCvService,
    private zone:   NgZone,
    private cdr:    ChangeDetectorRef,
  ) {
    addIcons({
      videocam, videocamOff, colorWand, lockClosedOutline,
      speedometerOutline, eyeOutline, informationCircleOutline,
      alertCircleOutline, refreshOutline,
    });
  }

  ngOnInit(): void {
    this.cvSub = this.opencv.ready$.subscribe(ready => {
      this.opencvReady.set(ready);
      this.cdr.markForCheck();
    });
  }

  ngAfterViewInit(): void {
    const canvas = this.canvasRef.nativeElement;
    canvas.width  = 640;
    canvas.height = 480;
    this.viewReady = true;
  }

  ngOnDestroy(): void {
    this.releaseCamera();
    this.cvSub?.unsubscribe();
  }

  async solicitarCamara(): Promise<void> {
    if (!this.viewReady) return;
    this.errorMsg.set('');
    this.appState.set('requesting');
    this.cdr.markForCheck();

    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: {
          facingMode: { ideal: 'environment' },
          width:  { ideal: 1280, min: 320 },
          height: { ideal: 720,  min: 240 },
        },
      });
      await this.iniciarCaptura();
    } catch (err: any) {
      const msg = this.mensajeError(err);
      this.appState.set('error');
      this.errorMsg.set(msg);
      this.cdr.markForCheck();
    }
  }

  async iniciarCaptura(): Promise<void> {
    if (!this.stream) return;

    const video  = this.videoRef.nativeElement;
    const canvas = this.canvasRef.nativeElement;

    video.srcObject = this.stream;

    await new Promise<void>((resolve, reject) => {
      video.onloadedmetadata = () => resolve();
      video.onerror = (e) => reject(e);
      setTimeout(() => reject(new Error('Timeout esperando video')), 5000);
    });

    await video.play();

    const settings = this.stream.getVideoTracks()[0].getSettings();
    canvas.width  = settings.width  ?? video.videoWidth  ?? 640;
    canvas.height = settings.height ?? video.videoHeight ?? 480;

    this.lastTime     = performance.now();
    this.fpsSmoothed  = 0;
    this.frameCounter = 0;

    this.appState.set('active');
    this.cdr.markForCheck();

    this.zone.runOutsideAngular(() => this.frameLoop());
  }

  detenerCaptura(): void {
    this.releaseCamera();

    const canvas = this.canvasRef?.nativeElement;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      ctx?.clearRect(0, 0, canvas.width, canvas.height);
      canvas.width  = 640;
      canvas.height = 480;
    }

    this.zone.run(() => {
      this.appState.set('idle');
      this.fps.set(0);
      this.sharpness.set(0);
      this.frameCount.set(0);
      this.cdr.markForCheck();
    });
  }

  reintentar(): void {
    this.appState.set('idle');
    this.errorMsg.set('');
    this.cdr.markForCheck();
  }

  private frameLoop(): void {
    if (this.appState() !== 'active') return;

    const video  = this.videoRef.nativeElement;
    const canvas = this.canvasRef.nativeElement;

    if (video.readyState < 2) {
      this.rafId = requestAnimationFrame(() => this.frameLoop());
      return;
    }

    const now   = performance.now();
    const delta = now - this.lastTime;
    this.lastTime = now;

  
    const ctx = canvas.getContext('2d', { willReadFrequently: true })!;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    // En esta zona se integra el tema que el frame sea analizado por su flujo de modelos
    // Les recomiendo crear un servicio para despues las modificaciones no interfieran en el
    // codigo que funciona
    /**
     * ONNX Runtime Web, bauticen su servicio con el nombre apropiado a su funcion 
     *
     * PASO 1 — Instalar
     *   npm install onnxruntime-web
     *
     * PASO 2 — Copiar los archivos WASM a src/assets/ort/
     *   cp node_modules/onnxruntime-web/dist/*.wasm src/assets/ort/
     *
     * PASO 3 — Copiar el modelo
     *   cp mi_modelo.onnx src/assets/modelo.onnx
     *
     * PASO 4 — Indicar la ruta de los WASM (antes de crear la sesión)
     *   ort.env.wasm.wasmPaths = 'assets/ort/';
     *
     * PASO 5 — Cargar el modelo una sola vez <-- importante!!! para optimizar funcionamiento
     *   session = await ort.InferenceSession.create('assets/modelo.onnx');
     *
     * PASO 6 — Inspeccionar el modelo con netron.app
     *   Verificar: nombre del input, shape esperado, nombre del output.
     *   También por código: console.log(session.inputNames, session.outputNames)
     *
     * PASO 7 — Preprocesar: canvas → Float32Array
     *   canvas (RGBA HWC) → resize → RGB CHW → normalizar → Float32Array
     *   Si el modelo usa ImageNet: aplicar mean/std por canal.
     *
     * PASO 8 — Ejecutar la sesión
     *   const feeds   = { [session.inputNames[0]]: new ort.Tensor('float32', data, [1,3,H,W]) };
     *   const results = await session.run(feeds);
     *   const logits  = results[session.outputNames[0]].data as Float32Array;
     *
     * PASO 9 — Postprocesar: logits → resultado
     *   Clasificación : argmax(logits) → clase,  softmax(logits) → confianza
     *   Detección     : filtrar por confianza → NMS → bounding boxes
     *
     * PASO 10 — Llamar desde frameLoop() sin bloquear
     *   this.inference.analyze(canvas).then(result => {
     *     this.zone.run(() => this.prediction.set(result));
     *   });
     *
     * PROBLEMAS FRECUENTES
     *   "Failed to fetch ort-wasm.wasm"  → verificar PASO 2 y PASO 4
     *   "SharedArrayBuffer is not defined"  → usar executionProviders: ['wasm']
     *   Shape mismatch  → revisar con Netron (PASO 6) y preprocesamiento (PASO 7)
     *   Video trabado   → usar .then() en lugar de await (PASO 10)
     */


    if (delta > 0) {
      const inst = 1000 / delta;
      this.fpsSmoothed = this.fpsSmoothed === 0
        ? inst
        : FPS_ALPHA * this.fpsSmoothed + (1 - FPS_ALPHA) * inst;
    }

    this.frameCounter++;

    // Sharpness cada N frames
    let newSharpness = this.sharpness();
    if (this.opencvReady() && this.frameCounter % SHARPNESS_EVERY === 0) {
      try { newSharpness = this.opencv.calcSharpness(canvas); } catch { /* ignorar */ }
    }

    // Actualizar UI cada N frames
    if (this.frameCounter % SHARPNESS_EVERY === 0) {
      this.zone.run(() => {
        this.fps.set(Math.round(this.fpsSmoothed));
        this.sharpness.set(newSharpness);
        this.frameCount.set(this.frameCounter);
        this.cdr.markForCheck();
      });
    }

    this.rafId = requestAnimationFrame(() => this.frameLoop());
  }

  private releaseCamera(): void {
    if (this.rafId !== null) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
    this.stream?.getTracks().forEach(t => t.stop());
    this.stream = null;
  }

  private mensajeError(err: any): string {
    switch (err?.name) {
      case 'NotAllowedError':
      case 'PermissionDeniedError':
        return 'Permiso de cámara denegado. Ve a Configuración del navegador → Privacidad → Cámara y permite el acceso.';
      case 'NotFoundError':
      case 'DevicesNotFoundError':
        return 'No se encontró ninguna cámara en este dispositivo.';
      case 'NotReadableError':
      case 'TrackStartError':
        return 'La cámara está en uso por otra aplicación. Ciérrala e intenta de nuevo.';
      case 'OverconstrainedError':
        return 'La resolución solicitada no es compatible con esta cámara.';
      default:
        return `Error de cámara: ${err?.message ?? String(err)}`;
    }
  }
}
