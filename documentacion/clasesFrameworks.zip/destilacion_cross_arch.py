"""
Frameworks de IA — Unidad 3 (Bonus Track)

Antes de partir.
La destilaciómn es una técnica un tanto problemática, puesto que si bien nació
para el proceso de transfer learning, también es una herramienta para "robarse"
el trabajo de entrenamiento de un modelo.
A estas alturas, espero, ya hayan entrenado sus modelos y visto el consumo de recursos
que lleva de manera conexa. Lo obvio es el uso de energía y el desgaste de las máquinas
que ejecutan el proceso... peeeero, se olvidaron del proceso de recolección de datos
para el entrenamiento. Aquí uds han utilizado datasets y modelos preentrenados que sirven
muy bien para iniciar soluciones más triviales. Pero imagina cosas un tanto más complejas,
por ejemplo uso de señales de radiofrecuencia para el monitoreo de transmisiones en contexto
de guerra o análisis de espectros de luz invisibles para la determinación de exoplanetas o
algo tan simple, como control de población en una granja de moluscos.
El armado de estos datasets consume mas del 60% (siendo bien conservador) del tiempo total
del proyecto. Y como si fuera poco, ninguno de los modelos preentrenados sirve y se debe iniciar
desde 0.
Primero vean este recurso: https://www.xataka.com/basics/que-modelos-destilados-inteligencia-artificial-destilacion-llm
Tenemos también algunos hilos muy interesantes sobre las implicaciones éticas: 
https://www.reddit.com/r/MachineLearning/comments/1idjtta/d_why_is_knowledge_distillation_now_suddenly/
intentos de prohibición (como si lograran algo, diganle a alguien no hagas esto para que lo haga con inistencia):
https://www.elespanol.com/omicrono/tecnologia/20260708/destilacion-ia-quieren-prohibir-rastreo-usuarios-amenaza-copiados-china/1003744312549_0.html
Desde el punto de vista de las grandes empresas de IA esto es un dolor de cabeza: 
https://araintel.com/articulos/los-ataques-que-mas-preocupan-a-los-gigantes-de-ia/
https://medium.com/@tahirbalarabe2/understanding-llm-distillation-attacks-929306ca38cd
https://www.bbc.com/mundo/articles/cx2jnpjdzzlo
https://www.xataka.com/robotica-e-ia/ia-campo-batalla-anthropic-acaba-acusar-a-deepseek-a-otras-empresas-chinas-destilar-claude
Bien, como sea lo primero es comprender que es una destilación, como se realiza y finalmente... hacer una.

Destilación entre arquitecturas: GPT-2 => GPT-Neo / TinyLlama

Implementa DOS Escenarios según el vocabulario del modelo destino:

  Escenario 1 — mismo vocabulario   (GPT-2 => GPT-Neo-125M)
    - Ambos usan el tokenizador GPT-2 (50.257 tokens)
    - Se pueden comparar los logits directamente => Usa KL divergence sobre distribuciones completas

  Escenario 2 — vocabulario diferente  (GPT-2 => TinyLlama-1.1B)
    - TinyLlama usa LLaMA tokenizador (32.000 tokens)
    No se pueden comparar logits directamente
    => GPT-2 genera texto => TinyLlama aprende ese texto (sequence-level KD)

Modelos usados (todos corren en CPU, Linux):
  GPT-2         : 124M params · ~500 MB RAM · vocab 50k
  GPT-Neo-125M  : 125M params · ~500 MB RAM · vocab 50k (EleutherAI)
  TinyLlama-1.1B: 1.1B params · ~2.2 GB RAM · vocab 32k (TinyLlama Team)

Instalación:
    pip install transformers torch accelerate

Uso:
    python destilacion_cross_arch.py                    # ambos Escenarios
    python destilacion_cross_arch.py --modo mismo_vocab # solo GPT-Neo
    python destilacion_cross_arch.py --modo seq_level   # solo TinyLlama
    
Nota: No se fijen tanto en las herramientas, por eso cambie a torch, sino en el flujo
y la mecánica de funcionamiento. Estos pasos son aplicables a cualquier modelo y tecnología.
"""

import os
import sys
import time
import math
import torch
import torch.nn.functional as F

os.environ["TOKENIZERS_PARALLELISM"] = "false"

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Dispositivo: {DEVICE}\n")

#  MODO 
# Cambia aquí o pasa --modo <opción> como argumento
MODO = "ambos"  # "mismo_vocab" | "seq_level" | "ambos"
for arg in sys.argv[1:]:
    if arg == "--modo" or arg.startswith("--modo="):
        MODO = sys.argv[sys.argv.index(arg)+1] if "=" not in arg else arg.split("=")[1]

#  CORPUS 
CORPUS = [
    "Artificial intelligence is transforming the way computers process language.",
    "Deep learning models learn hierarchical representations from raw data.",
    "The transformer architecture uses self-attention to process sequences.",
    "Language models predict the next token given previous context tokens.",
    "Knowledge distillation transfers information from large to small models.",
    "Neural networks are optimized using gradient descent and backpropagation.",
    "Transfer learning allows models to leverage knowledge from related tasks.",
    "Attention mechanisms enable models to focus on relevant input parts.",
    "Pre-trained models can be fine-tuned efficiently on downstream tasks.",
    "Temperature scaling softens probability distributions over vocabulary.",
    "The student model learns to mimic the teacher probability distributions.",
    "Tokenization converts raw text into numerical representations for models.",
    "Small models run faster and require less memory during inference.",
    "The softmax function converts raw logits into probability distributions.",
    "KL divergence measures the difference between two probability distributions.",
    "Training large models requires significant computational resources.",
    "Language model perplexity measures prediction uncertainty on text.",
    "Sequence level distillation uses generated text as training signal.",
    "Cross architecture distillation requires vocabulary alignment strategies.",
    "Open source language models enable local inference without cloud APIs.",
]

# ══════════════════════════════════════════════════════════════════════
# Escenario 1 — MISMO VOCABULARIO: GPT-2 => GPT-Neo-125M
# Método: KL Divergence sobre logits (soft-label distillation)
# ══════════════════════════════════════════════════════════════════════

def Escenario_mismo_vocab():
    from transformers import (
        GPT2LMHeadModel, GPT2Tokenizer,
        GPTNeoForCausalLM, GPT2Config
    )

    print("=" * 60)
    print("Escenario 1 — Mismo vocabulario")
    print("Profesor: GPT-2  =>  estudiante: GPT-Neo-125M")
    print("Método  : KL Divergence sobre logits completos")
    print("=" * 60)

    #  Configuración ─
    TEMPERATURA  = 4.0
    ALPHA        = 0.7    # peso KL divergence
    LR           = 3e-4
    EPOCHS       = 2
    MAX_LEN      = 64
    BATCH_SIZE   = 2

    #  Tokenizador compartido ─
    # GPT-2 y GPT-Neo comparten el mismo tokenizador BPE de 50.257 tokens
    # Esto es lo que permite comparar los logits directamente
    print("\nCargando tokenizador GPT-2 (compartido por ambos modelos)...")
    tokenizador = GPT2Tokenizer.from_pretrained("gpt2")
    tokenizador.pad_token = tokenizador.eos_token
    print(f"  Vocabulario compartido: {tokenizador.vocab_size:,} tokens")

    #  Profesor: GPT-2 ─
    print("\nCargando Profesor: GPT-2 (124M)...")
    profesor = GPT2LMHeadModel.from_pretrained("gpt2").to(DEVICE)
    profesor.eval()
    for p in profesor.parameters():
        p.requires_grad = False
    print(f"  {sum(p.numel() for p in profesor.parameters()):,} parámetros (congelados)")

    #  estudiante: GPT-Neo-125M 
    # GPT-Neo es de EleutherAI — arquitectura distinta a GPT-2:
    #   GPT-2    : vanilla attention + learned position embeddings
    #   GPT-Neo  : global attention + learned position embeddings
    #             entrenado en The Pile (800GB) vs WebText (40GB)
    print("\nCargando estudiante: GPT-Neo-125M (EleutherAI)...")
    estudiante = GPTNeoForCausalLM.from_pretrained(
        "EleutherAI/gpt-neo-125m"
    ).to(DEVICE)
    print(f"  {sum(p.numel() for p in estudiante.parameters()):,} parámetros")
    print(f"  Arquitectura: {estudiante.config.num_layers} capas · "
          f"{estudiante.config.hidden_size} hidden · "
          f"attention: {estudiante.config.attention_types}")

    #  Datos ─
    def preparar_datos(corpus, tok, max_len, batch_size):
        ids_lista = []
        for texto in corpus:
            ids = tok.encode(
                texto, max_length=max_len, truncation=True,
                padding="max_length", return_tensors="pt"
            )
            ids_lista.append(ids)
        todos = torch.cat(ids_lista, dim=0)
        return [todos[i:i+batch_size] for i in range(0, len(todos), batch_size)
                if todos[i:i+batch_size].size(0) == batch_size]

    batches = preparar_datos(CORPUS, tokenizador, MAX_LEN, BATCH_SIZE)
    print(f"\n  Batches: {len(batches)}")

    #  Función de pérdida 
    def perdida_kl(logits_estudiante, logits_profesor, labels, T, alpha):
        """
        KL divergence sobre vocabulario completo.

        Posible porque ambos modelos tienen el mismo vocabulario (50.257).
        logits_estudiante[i,t,v]   = puntuación del estudiante para token v en posición t
        logits_profesor[i,t,v] = puntuación del profesor (sin gradientes)

        KL(prof || alum) = sum(prob_prof * log(prob_prof / prob_alum))
        Multiplicado por T² para compensar el escalado de temperatura.
        """
        V = logits_estudiante.size(-1)

        # Suavizar con temperatura T
        log_alum = F.log_softmax(logits_estudiante / T, dim=-1)
        prob_prof = F.softmax(logits_profesor / T, dim=-1)

        # KL divergence
        loss_kl = F.kl_div(
            log_alum.view(-1, V),
            prob_prof.view(-1, V),
            reduction="batchmean"
        ) * (T ** 2)

        # Cross-entropy con etiquetas reales (next token prediction)
        shift_logits = logits_estudiante[:, :-1].contiguous()
        shift_labels = labels[:, 1:].contiguous()
        loss_ce = F.cross_entropy(
            shift_logits.view(-1, V),
            shift_labels.view(-1),
            ignore_index=tokenizador.pad_token_id
        )

        return alpha * loss_kl + (1 - alpha) * loss_ce

    #  Entrenamiento ─
    optimizer = torch.optim.AdamW(estudiante.parameters(), lr=LR, weight_decay=0.01)

    print(f"\nEntrenando GPT-Neo con KL divergence...")
    print(f"  T={TEMPERATURA} · α(KL)={ALPHA} · lr={LR} · {EPOCHS} épocas\n")

    for epoca in range(1, EPOCHS + 1):
        estudiante.train()
        losses, t0 = [], time.time()

        for batch in batches:
            ids = batch.to(DEVICE)

            # Profesor: logits suaves (sin gradientes)
            with torch.no_grad():
                logits_prof = profesor(input_ids=ids).logits

            # estudiante: logits con gradientes
            optimizer.zero_grad()
            logits_alum = estudiante(input_ids=ids).logits

            loss = perdida_kl(logits_alum, logits_prof, ids, TEMPERATURA, ALPHA)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(estudiante.parameters(), 1.0)
            optimizer.step()
            losses.append(loss.item())

        avg = sum(losses)/len(losses)
        print(f"  Época {epoca}/{EPOCHS} | Loss: {avg:.4f} | {time.time()-t0:.1f}s")

    #  Guardar y comparar 
    ruta = "gpneo_destilado.pt"
    torch.save({"model_state": estudiante.state_dict(),
                "config": estudiante.config.to_dict()}, ruta)
    print(f"\n  estudiante guardado en '{ruta}' "
          f"({os.path.getsize(ruta)/1024/1024:.0f} MB)")

    # Comparativa de generación
    prompt = "Artificial intelligence is"
    ids_p  = tokenizador.encode(prompt, return_tensors="pt").to(DEVICE)

    def generar(modelo, ids, max_new=40):
        with torch.no_grad():
            out = modelo.generate(
                ids, max_new_tokens=max_new, do_sample=True,
                temperature=0.8, top_p=0.9,
                pad_token_id=tokenizador.eos_token_id
            )
        return tokenizador.decode(out[0], skip_special_tokens=True)

    estudiante.eval()
    print(f"\n  Prompt: '{prompt}'")
    print(f"\n  Profesor (GPT-2)  : {generar(profesor, ids_p)}")
    print(f"  estudiante (GPT-Neo)  : {generar(estudiante, ids_p)}")

    print("\n - Escenario 1 completado")
    return estudiante, tokenizador


# ══════════════════════════════════════════════════════════════════════
# Escenario 2 — VOCABULARIO DIFERENTE: GPT-2 => TinyLlama-1.1B
# Método: Sequence-Level Knowledge Distillation
# ══════════════════════════════════════════════════════════════════════

def Escenario_seq_level():
    from transformers import (
        GPT2LMHeadModel, GPT2Tokenizer,
        AutoModelForCausalLM, AutoTokenizer
    )

    print("=" * 60)
    print("Escenario 2 — Vocabulario diferente")
    print("Profesor: GPT-2  =>  estudiante: TinyLlama-1.1B")
    print("Método  : Sequence-Level Knowledge Distillation")
    print("=" * 60)
    print("""
Idea clave:
  Cuando los vocabularios son distintos NO se pueden comparar
  los logits directamente. En cambio:

  1. El profesor GENERA texto completo a partir de prompts
  2. Ese texto generado se convierte en los datos de entrenamiento
  3. El estudiante aprende a predecirlo con cross-entropy normal

  El estudiante no ve los logits del profesor — aprende de su OUTPUT.
  Esto es exactamente cómo se entrenan modelos como Alpaca,
  Vicuna o muchos LLMs open-source: aprenden de texto
  generado por GPT-4, Claude u otros modelos más grandes.
""")

    #  Configuración ─
    LR          = 2e-5    # LR bajo para no arruinar TinyLlama
    EPOCHS      = 1       # una época es suficiente para la demo
    MAX_LEN_GEN = 60      # tokens que genera el profesor por prompt
    MAX_LEN_STU = 128     # contexto máximo del estudiante
    BATCH_SIZE  = 1       # TinyLlama en CPU requiere batch pequeño

    #  Tokenizador del profesor ─
    print("Cargando Profesor: GPT-2...")
    tok_prof = GPT2Tokenizer.from_pretrained("gpt2")
    tok_prof.pad_token = tok_prof.eos_token
    profesor = GPT2LMHeadModel.from_pretrained("gpt2").to(DEVICE)
    profesor.eval()
    for p in profesor.parameters():
        p.requires_grad = False
    print(f"  Vocab profesor: {tok_prof.vocab_size:,} tokens")

    #  Tokenizador del estudiante ─
    print("\nCargando estudiante: TinyLlama-1.1B...")
    print("  (primera vez: ~2.2 GB de descarga)")
    tok_alum = AutoTokenizer.from_pretrained("TinyLlama/TinyLlama-1.1B-intermediate-step-1431k-3T")
    if tok_alum.pad_token is None:
        tok_alum.pad_token = tok_alum.eos_token
    estudiante = AutoModelForCausalLM.from_pretrained(
        "TinyLlama/TinyLlama-1.1B-intermediate-step-1431k-3T",
        torch_dtype=torch.float32,   # float32 para CPU
        low_cpu_mem_usage=True
    ).to(DEVICE)
    print(f"  Vocab estudiante  : {tok_alum.vocab_size:,} tokens")
    print(f"  Parámetros    : {sum(p.numel() for p in estudiante.parameters())/1e9:.2f}B")

    #  PASO 1: Profesor genera texto ─
    print("\n Paso 1: Generando texto con el profesor (GPT-2) ─")
    prompts = [
        "Artificial intelligence is",
        "Deep learning models learn",
        "The transformer architecture",
        "Language models predict",
        "Knowledge distillation transfers",
        "Neural networks are optimized",
        "Transfer learning allows",
        "Attention mechanisms enable",
        "Pre-trained models can be",
        "Temperature scaling softens",
    ]

    textos_generados = []
    for prompt in prompts:
        ids = tok_prof.encode(prompt, return_tensors="pt").to(DEVICE)
        with torch.no_grad():
            out = profesor.generate(
                ids,
                max_new_tokens  = MAX_LEN_GEN,
                do_sample       = True,
                temperature     = 0.8,
                top_p           = 0.9,
                pad_token_id    = tok_prof.eos_token_id,
            )
        texto = tok_prof.decode(out[0], skip_special_tokens=True)
        textos_generados.append(texto)
        print(f"  ✓ {texto[:70]}...")

    print(f"\n  {len(textos_generados)} secuencias generadas")

    #  PASO 2: Tokenizar con el vocab del estudiante ─
    print("\n Paso 2: Tokenizando con vocab de TinyLlama ")
    # El texto generado por el profesor se tokeniza con el tokenizador
    # del estudiante — vocabulario completamente diferente
    ids_lista = []
    for texto in textos_generados:
        enc = tok_alum.encode(
            texto,
            max_length   = MAX_LEN_STU,
            truncation   = True,
            padding      = "max_length",
            return_tensors = "pt"
        )
        ids_lista.append(enc)

    todos_ids = torch.cat(ids_lista, dim=0)
    batches   = [todos_ids[i:i+BATCH_SIZE]
                 for i in range(0, len(todos_ids), BATCH_SIZE)
                 if todos_ids[i:i+BATCH_SIZE].size(0) == BATCH_SIZE]
    print(f"  {len(batches)} batches listos para entrenar al estudiante")

    #  PASO 3: Entrenar al estudiante 
    print(f"\n Paso 3: Entrenando TinyLlama con cross-entropy normal ─")
    print(f"  LR={LR} · {EPOCHS} época(s) · batch={BATCH_SIZE}")
    print("""
  Nota: esto es cross-entropy estándar — no hay magia nueva.
  La "destilación" ocurrió en el Paso 1 cuando el profesor
  generó texto de alta calidad. Aquí el estudiante simplemente
  aprende a predecir ese texto.
""")

    # Entrenamos solo los últimos N bloques para ser eficientes en CPU
    # En producción entrenas todo el modelo
    BLOQUES_A_ENTRENAR = 2
    for nombre, param in estudiante.named_parameters():
        param.requires_grad = False

    # Descongelar últimas N capas del transformer
    n_capas = estudiante.config.num_hidden_layers
    for nombre, param in estudiante.named_parameters():
        for bloque in range(n_capas - BLOQUES_A_ENTRENAR, n_capas):
            if f"layers.{bloque}." in nombre or "lm_head" in nombre:
                param.requires_grad = True

    entrenables = sum(p.numel() for p in estudiante.parameters() if p.requires_grad)
    print(f"  Parámetros entrenables: {entrenables/1e6:.1f}M "
          f"(últimos {BLOQUES_A_ENTRENAR} bloques)")

    optimizer = torch.optim.AdamW(
        filter(lambda p: p.requires_grad, estudiante.parameters()),
        lr=LR, weight_decay=0.01
    )

    for epoca in range(1, EPOCHS + 1):
        estudiante.train()
        losses, t0 = [], time.time()
        for batch in batches:
            ids = batch.to(DEVICE)
            optimizer.zero_grad()
            # Loss = cross-entropy next-token prediction
            # Exactamente igual que pre-entrenamiento normal
            salida = estudiante(input_ids=ids, labels=ids)
            salida.loss.backward()
            torch.nn.utils.clip_grad_norm_(
                filter(lambda p: p.requires_grad, estudiante.parameters()), 1.0
            )
            optimizer.step()
            losses.append(salida.loss.item())
        avg = sum(losses)/len(losses)
        print(f"  Época {epoca}/{EPOCHS} | Loss: {avg:.4f} | {time.time()-t0:.1f}s")

    #  Guardar y comparar 
    ruta = "tinyllama_destilado.pt"
    torch.save({
        "model_state"   : estudiante.state_dict(),
        "config"        : estudiante.config.to_dict(),
        "textos_profesor": textos_generados,
    }, ruta)
    print(f"\n  estudiante guardado en '{ruta}' "
          f"({os.path.getsize(ruta)/1024/1024:.0f} MB)")

    # Comparativa de generación
    prompt_prueba = "Artificial intelligence enables"
    print(f"\n  Prompt: '{prompt_prueba}'")

    ids_prof = tok_prof.encode(prompt_prueba, return_tensors="pt").to(DEVICE)
    with torch.no_grad():
        out_prof = profesor.generate(
            ids_prof, max_new_tokens=40, do_sample=True,
            temperature=0.8, top_p=0.9, pad_token_id=tok_prof.eos_token_id
        )
    print(f"\n  Profesor (GPT-2)    : {tok_prof.decode(out_prof[0], skip_special_tokens=True)}")

    estudiante.eval()
    ids_alum = tok_alum.encode(prompt_prueba, return_tensors="pt").to(DEVICE)
    with torch.no_grad():
        out_alum = estudiante.generate(
            ids_alum, max_new_tokens=40, do_sample=True,
            temperature=0.8, top_p=0.9, pad_token_id=tok_alum.eos_token_id
        )
    print(f"  estudiante (TinyLlama)  : {tok_alum.decode(out_alum[0], skip_special_tokens=True)}")

    print("\n  Escenario 2 completado")
    return estudiante, tok_alum


#  RESUMEN COMPARATIVO ─
def imprimir_resumen():
    print("\n" + "═" * 60)
    print("  RESUMEN: Dos Escenarios de destilación cross-architecture")
    print("═" * 60)

    filas = [
        ("Aspecto",            "Escenario 1 (KL Div)",     "Escenario 2 (Seq-Level)"),
        ("─" * 20,             "─" * 20,                  "─" * 20),
        ("Modelos",            "GPT-2 => GPT-Neo",         "GPT-2 => TinyLlama"),
        ("Vocabulario",        "Mismo (50k)",              "Distinto (50k vs 32k)"),
        ("Qué aprende",        "Distribución completa",    "Texto generado"),
        ("Señal de aprendizaje","Logits suaves (T=4)",     "Tokens generados"),
        ("Pérdida",            "KL Divergence",            "Cross-Entropy"),
        ("Información trans.",  "Alta (toda la distr.)",   "Media (solo output)"),
        ("Complejidad",        "Media",                    "Baja"),
        ("Casos de uso",       "Mismo dominio",            "Cualquier arquitectura"),
    ]

    for cols in filas:
        print(f"  {cols[0]:<22} {cols[1]:<22} {cols[2]}")

    print("""
  Cuándo elegir cada uno:
  ─
  => Mismo vocabulario: cuando el estudiante pertenece a la misma
    familia de modelos o fue diseñado con el mismo tokenizador.
    Más eficiente — el estudiante aprende la distribución completa.

  => Vocabulario diferente: cuando quieres destilar a cualquier
    LLM moderno (LLaMA, Mistral, Falcon, Phi, Gemma).
    Es el Escenario que usaron Alpaca, Vicuna y la mayoría de
    los LLMs open-source: aprendieron de texto generado por GPT-4.
""")


#  MAIN 
if __name__ == "__main__":
    if MODO in ("mismo_vocab", "ambos"):
        Escenario_mismo_vocab()
        print()

    if MODO in ("seq_level", "ambos"):
        Escenario_seq_level()

    imprimir_resumen()
    

"""
 Este es un código relativamente antiguo de finales del 2020,
 originalmente el flujo de trabajo destilaba un modelo comercial de cientos de millones
 de parámetros a uno adhoc de mucho menor capacidad dentro del contexto de visión computacional.
 Ahora, lo importante, el flujo es el mismo, en lugar de una tabla con codec se utiliza un
 vocabulario y se agregó un escenario (el numero 1). 
 Obviamente el script original no utilizaba prompts sino requests de identificación,
 pero utilizaba el mismo patrón: Profesor (fuente) - Estudiante (destino).
 Si ya llegaste aquí leyendo antes de ejecutar a lo salvaje este código, te recomiendo
 un ambiente nuevo, no reutilices lo que tienes e instala ollama:  curl -fsSL https://ollama.com/install.sh | sh
 El principal problema de instalar ollama es la memoria si estas en una instancia en AWS elije las que tengan
 8GB de ram. Y otro problema que puedes tener es la GPU, verifica bien que tengas correctamente instalado CUDA en caso de tener
 GPU, si no tienes GPU no deberías tener problemas... énfasis en "deberías".
 No te olvides de la secuencia lógica del tema versiones: Python => Dependencias, te recomiendo que uses algún gestor de versiones
 de Python, pues su versionamiento define las versiones de las dependencias a las que puedes subir o bajar.
 
 Suerte.
 
 Miniminimini Glosario:
 
 KL divergence: es una métrica que mide la pérdida de información al usar una distribución aproximada en lugar de la real. Esta pérdida
 no es simétrica lo que se traduce en P=>Q <=/=> Q=>P. Si la diferencia entre P y Q es 0, significa que ambas son iguales (obvio).
 ¿Para qué sirve?... no se... digamos... ¿Destilado de conocimiento? como para saber si el Estudiante, no se, igualo al Profesor.
 Soft-label destilation: este método se basa en que el modelo receptor es pequeño y rápido. Se entrena imitando las respuestas (probabilidades) del Origen (Profesor)
 de manera detallada. Es decir, no enseña el resultado final sino que distribuye las dudas y certezas de la respuesta entre todas las opciones posibles.
 La ventaja de este tipo de destilación, es que se logra transferir el entrenamiento oscuro hacia el estudiante (¿recuerdas a que nos referimos con oscuro u oculto en una red?)
 Logits: En el contexto de destilación anterior, los logits corresponden a los pesos brutos de la ultima capa del modelo maestro que sirve como pauta pedagogica detallada para 
 el modelo estudiante.
 Sequence-Level Knowledge Distillation (SeqKD): Corresponde a una variante de destilación de modelos especificas para LLM y tareas de generación de texto como traductores. Una de 
 las diferencias es que aquí no se entrena por palabra al estudiante sino por secuencias o frases de texto completas generadas por el Profesor.
 Este método apareció el 2016 en el paper de Kim y Rush (2016) https://aclanthology.org/D16-1139/
 
"""
